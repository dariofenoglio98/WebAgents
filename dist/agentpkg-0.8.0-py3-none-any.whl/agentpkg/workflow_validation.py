"""Offline semantic checks for the workflow.v0 execution profile."""

from __future__ import annotations

from .errors import ValidationError
from .validation import (
    _schema_reference,
    _unique,
    parse_json,
    release,
    validate_document,
    validate_instance,
)
from .workflow_values import references, tokens


def _at_schema(schema, parts, path, documents, label, seen=None):
    """Reject statically impossible pointers; optional data is checked again at runtime."""
    seen = set() if seen is None else seen
    if schema is True or schema == {}:
        return {}
    if not isinstance(schema, dict):
        raise ValidationError(f"{label}: projection targets a forbidden schema")
    if "$ref" in schema:
        target, fragment = _schema_reference(path, schema["$ref"])
        key = (target, fragment, tuple(parts))
        if key in seen:
            raise ValidationError(f"{label}: recursive projection cannot be resolved")
        from .workflow_values import select

        return _at_schema(
            select(documents[target], fragment), parts, target, documents, label, seen | {key}
        )
    if not parts:
        return schema
    for union in ("anyOf", "oneOf", "allOf"):
        if union in schema:
            for choice in schema[union]:
                try:
                    return _at_schema(choice, parts, path, documents, label, seen)
                except ValidationError:
                    pass
            raise ValidationError(f"{label}: no schema alternative contains projection")
    key, *rest = parts
    if schema.get("type") == "array":
        if not key.isdigit() or str(int(key)) != key:
            raise ValidationError(f"{label}: array projection needs a canonical numeric index")
        child = schema.get("items", {})
    else:
        types = schema.get("type", ["object"])
        types = [types] if isinstance(types, str) else types
        if "object" not in types:
            raise ValidationError(f"{label}: cannot traverse a scalar schema")
        child = schema.get("properties", {}).get(key)
        if child is None:
            child = schema.get("additionalProperties", True)
            if child is False:
                raise ValidationError(f"{label}: state/data path component {key!r} not declared")
    return _at_schema(child, rest, path, documents, label, seen)


#: The first runtime that evaluates answer checks (`checks` on an llm node or map llm step).
CHECKS_MINIMUM_VERSION = (0, 3, 0)


def _declares_checks(graph):
    from .delegation.analysis import role_steps

    for node in graph["nodes"]:
        if "checks" in node or any("checks" in step for step in node.get("steps", [])):
            return True
    return any("checks" in step for _, step in role_steps(graph))


def validate_workflow(manifest, graph, policy, tools, files):
    if manifest["entrypoint"] != "workflow.v0":
        raise ValidationError("workflow.v0 graph requires entrypoint workflow.v0")
    minimum = release(manifest["runtime"]["minimum_version"])
    if _declares_checks(graph) and minimum < CHECKS_MINIMUM_VERSION:
        # An older runtime would refuse the unknown field anyway; declaring the minimum makes it
        # refuse the package by its version, with the reason a person can act on.
        raise ValidationError("answer checks require runtime.minimum_version 0.3.0 or later")
    from .compute.declarations import check_compute_declarations
    from .conversation.declarations import (
        check_conversation_declarations,
        conversation_initial_env,
    )

    # compute.v0 (agentpkg 0.5.0): the modules, the members, the nodes' functions and the
    # permission agree before anything else is checked; a graph without any of it passes.
    check_compute_declarations(manifest, graph, policy, files)
    schema_paths = {s["path"] for s in manifest["schemas"]}
    documents = {p: parse_json(files[p], p) for p in schema_paths}
    workers = {r["id"]: r for r in graph["workers"]}
    tasks = {t["id"] for t in manifest["model_requirements"]["tasks"]}
    nodes = _unique(graph["nodes"], "workflow nodes")
    state_path = policy["memory"]["state_schema"]
    coordinator = graph["coordinator"]
    if policy["delegation"]["max_depth"] != 1 or policy["delegation"]["allow_remote"]:
        raise ValidationError("workflow.v0 requires local delegation max_depth=1")
    if any(w["kind"] != "packaged" for w in workers.values()):
        raise ValidationError("workflow.v0 supports packaged workers only")
    if any(t["retries"] != 0 or t["execution"] == "agent" for t in tools.values()):
        raise ValidationError("workflow.v0 supports local/remote tools with retries=0")

    def schema(path, label):
        if path not in schema_paths:
            raise ValidationError(f"{label}: undeclared schema {path!r}")
        return documents[path], path

    schema(graph["input_schema"], "workflow input")
    schema(graph["output_schema"], "workflow output")
    ancestors = {}
    visiting = set()

    def visit(nid):
        if nid in visiting:
            raise ValidationError(f"workflow node {nid}: cyclic dependency")
        if nid in ancestors:
            return ancestors[nid]
        visiting.add(nid)
        node = nodes[nid]
        found = set()
        for dep in node["depends_on"]:
            if dep not in nodes:
                raise ValidationError(f"workflow node {nid}: unknown dependency {dep!r}")
            found.add(dep)
            found.update(visit(dep))
        visiting.remove(nid)
        ancestors[nid] = found
        return found

    for nid in nodes:
        visit(nid)
    outputs = [n for n in nodes.values() if n["type"] == "output"]
    if len(outputs) != 1:
        raise ValidationError("workflow requires exactly one output node")
    output = outputs[0]
    if ancestors[output["id"]] != set(nodes) - {output["id"]}:
        raise ValidationError(f"output node {output['id']} must depend on every other node")
    if output["output_schema"] != graph["output_schema"]:
        raise ValidationError("output node schema must equal workflow output_schema")
    reads = {nid: set() for nid in nodes}
    writes = {nid: set() for nid in nodes}

    def expression(value, env, label, role=None, nid=None):
        for source, pointer in references(value):
            if source not in env:
                raise ValidationError(f"{label}: source {source!r} is unavailable in this scope")
            parts = tokens(pointer)
            if source == "state":
                if role is not None:
                    if not parts or parts[0] not in workers[role]["state_read"]:
                        raise ValidationError(f"{label}: projection exceeds {role} state_read")
                elif not parts:
                    # Without a role (network.v0's `result`, read by the network itself over
                    # its own state), the key only has to exist in the schema, checked below.
                    raise ValidationError(f"{label}: whole-state reads are forbidden")
                if nid is not None:
                    # A network role's program (network.v0) reads the network's own state, not
                    # the graph's: its reads take no part in the top-level conflict analysis.
                    reads[nid].add(parts[0])
            if source == "steps":
                if not parts or parts[0] not in env["steps"]:
                    raise ValidationError(f"{label}: unknown or forward step reference")
                root, path = env["steps"][parts[0]]
                parts = parts[1:]
            else:
                root, path = env[source]
            _at_schema(root, parts, path, documents, label)

    # conversation.v0 (agentpkg 0.6.0): a conversational graph's initial state also reads the
    # persisted state, typed by the conversation's state schema; nowhere else (V-4).
    expression(
        graph["initial_state"],
        {"input": schema(graph["input_schema"], "input")}
        | conversation_initial_env(graph, documents, schema_paths),
        "initial_state",
    )

    def operation(node, role, env, label, nid):
        schema(node["output_schema"], label)
        expression(node["input"], env, label + "/input", role, nid)
        if "when" in node:
            for side in ("left", "right"):
                expression(node["when"][side], env, label + "/when", role, nid)
            expression(node["otherwise"], env, label + "/otherwise", role, nid)
        for assertion in node.get("assertions", []):
            for key in ("left", "right", "rows", "targets", "equals"):
                if key in assertion:
                    expression(assertion[key], env, label + "/assertions/" + key, role, nid)
        # Answer checks see the operation's own sources and the answer itself as `result`.
        answer_env = env | {"result": schema(node["output_schema"], label)}
        for check in node.get("checks", []):
            for key in ("left", "right", "rows", "targets", "equals"):
                if key in check:
                    expression(check[key], answer_env, label + "/checks/" + key, role, nid)
        kind = node["type"]
        if kind == "llm" and node["task"] not in tasks:
            raise ValidationError(f"{label}: undeclared model task {node['task']!r}")
        if kind == "consent":
            # The sentence shown is constructed like the input, under the same scope rules.
            expression(node["text"], env, label + "/text", role, nid)
        if kind == "compute":
            # The constructed input is checked against the module's own input contract before
            # the call, as a tool's is; both schemas are declared package schemas.
            schema(node["input_schema"], label + "/input_schema")
        if kind == "tool":
            if node["tool"] not in tools:
                raise ValidationError(f"{label}: unknown tool {node['tool']!r}")
            if node["tool"] not in workers[role]["tools"]:
                raise ValidationError(f"{label}: tool is not authorized for worker {role}")
        if kind == "map":
            if "when" in node:
                raise ValidationError(f"{label}: map conditions unsupported; use an empty array")
            if node["max_parallel"] > min(
                workers[role]["max_instances"], policy["budget"]["max_parallel_workers"]
            ):
                raise ValidationError(f"{label}: max_parallel exceeds worker/package limits")
            item = schema(node["item_schema"], label + "/item_schema")
            _unique(node["steps"], label + "/steps")
            step_env = env | {"item": item, "steps": {}}
            for step in node["steps"]:
                operation(step, role, step_env, label + "/" + step["id"], nid)
                step_env["steps"][step["id"]] = schema(step["output_schema"], label)
            expression(node["yield"], step_env, label + "/yield", role, nid)
        if kind in {"llm", "tool", "map", "link"} and role == coordinator:
            raise ValidationError(f"{label}: effectful nodes require a non-coordinator worker")

    for nid, node in nodes.items():
        role = node["worker"]
        label = f"workflow node {nid}"
        if role not in workers:
            raise ValidationError(f"{label}: unknown worker {role!r}")
        env = {"state": (documents[state_path], state_path)}
        operation(node, role, env, label, nid)
        for pointer, value in node["writes"].items():
            parts = tokens(pointer)
            if len(parts) != 1 or parts[0] not in workers[role]["state_write"]:
                raise ValidationError(f"{label}: writes must target one authorized state_write key")
            writes[nid].add(parts[0])
            expression(
                value,
                {"result": schema(node["output_schema"], label)},
                label + "/writes/" + pointer,
                role,
                nid,
            )
        if node["type"] == "output" and node["writes"]:
            raise ValidationError(f"{label}: output cannot write state")
    # Unordered conflicting accesses are invalid, independent of incidental array order.
    for a in nodes:
        for b in nodes:
            if a != b and a not in ancestors[b] and b not in ancestors[a]:
                conflict = writes[a] & (reads[b] | writes[b])
                if conflict:
                    raise ValidationError(
                        f"workflow nodes {a}/{b}: unordered state conflict "
                        f"{sorted(conflict)}; add a dependency"
                    )
    initial = graph["initial_state"]
    initial_keys = (
        set(initial["object"])
        if "object" in initial
        else set(initial["literal"])
        if isinstance(initial.get("literal"), dict)
        else None
    )
    if initial_keys is not None:
        for nid in nodes:
            available = initial_keys | {key for dep in ancestors[nid] for key in writes[dep]}
            missing = reads[nid] - available
            if missing:
                raise ValidationError(
                    f"workflow node {nid}: read before initialization {sorted(missing)}"
                )
    exported = set()
    for export in graph.get("exports", []):
        from .package import _safe_name

        _safe_name(export["path"])
        name = export["path"].lower()
        if name in exported or name in {
            "result.json",
            "audit.json",
            "usage.json",
            "provenance.json",
        }:
            raise ValidationError(f"duplicate or reserved export path {name}")
        exported.add(name)
        expression(
            export["value"], {"result": schema(graph["output_schema"], "export")}, "export " + name
        )
    if graph.get("fixture"):
        path = graph["fixture"]
        if path not in files:
            raise ValidationError(f"missing workflow fixture {path}")
        fixture = parse_json(files[path], path)
        validate_document(fixture, "workflow-fixture", path)
        validate_instance(files, graph["input_schema"], fixture["input"], "fixture input")
        import json

        for cases in list(fixture["models"].values()) + list(fixture["tools"].values()):
            inputs = [json.dumps(c["input"], sort_keys=True) for c in cases]
            if len(set(inputs)) != len(inputs):
                raise ValidationError("fixture contains duplicate input cases")
        if set(fixture["models"]) - tasks or set(fixture["tools"]) - set(tools):
            raise ValidationError("fixture contains undeclared model task/tool")
        for tid, cases in fixture["tools"].items():
            for case in cases:
                for field in ("input", "output"):
                    validate_instance(
                        files,
                        tools[tid][field + "_schema"],
                        case[field],
                        f"fixture tool {tid} {field}",
                    )
    # network.v0 (agentpkg 0.7.0): the network object, its one node, the roles against the
    # workers, the edges, the state views, each role's program (checked with `operation` over
    # its own sources) and the bound against the package's budget; a graph without a network
    # passes (and may hold no network node).
    from .delegation.declarations import check_network_declarations

    check_network_declarations(
        manifest,
        graph,
        policy,
        tools,
        files,
        documents=documents,
        schema=schema,
        expression=expression,
        operation=operation,
        nodes=nodes,
    )
    # link.v0 (agentpkg 0.8.0): the dependency records, every `link` step against them, the
    # slots and their ceilings against the package's budget; a package without a dependency or
    # a link step passes. What needs a linked package's own declaration waits for preparation.
    from .links.declarations import check_link_declarations

    check_link_declarations(
        manifest,
        graph,
        policy,
        files,
        documents=documents,
        schema=schema,
        expression=expression,
        at_schema=_at_schema,
    )
    # conversation.v0: the conversation object, the consent steps, the gate before every tool
    # that links a consented permission, and the fixture transcript; a graph without a
    # conversation passes (and may hold no consent step).
    check_conversation_declarations(
        manifest,
        graph,
        policy,
        tools,
        files,
        documents=documents,
        schema=schema,
        expression=expression,
        ancestors=ancestors,
        nodes=nodes,
    )
