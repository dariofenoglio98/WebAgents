"""Executable developer commands; application execution is explicit host dispatch."""

from __future__ import annotations

import argparse
import asyncio
import json
import signal
import sys
from pathlib import Path

from . import __version__
from .errors import AgentPkgError, ValidationError
from .package import (
    _open_parent,
    build_package,
    inspect_package,
    load_package,
    permissions_summary,
    unpack_package,
    write_new,
)
from .signing import keygen, sign_package, verify_package
from .validation import parse_json


class _Exit(int):
    """A command's exit status, for commands that own stdout themselves."""


def _json_file(path, expected_type=dict):
    value = parse_json(Path(path).read_bytes(), str(path))
    if expected_type is not None and not isinstance(value, expected_type):
        raise ValidationError(f"{path}: expected JSON {expected_type.__name__}")
    return value


def _pairs(values, flag) -> dict:
    """Repeatable `ID=VALUE` arguments as a map; an id named twice is refused."""
    found = {}
    for value in values or ():
        name, separator, rest = value.partition("=")
        if not separator or not name or not rest:
            raise AgentPkgError(f"{flag} takes ID=VALUE, got {value!r}")
        if name in found:
            raise AgentPkgError(f"{flag} names {name!r} twice")
        found[name] = rest
    return found


def _verify_under(path, trust_keys) -> dict:
    """The archive verified under one of the operator's pinned keys."""
    failure = None
    for key in trust_keys:
        try:
            return verify_package(path, trusted_key=key)
        except AgentPkgError as exc:
            failure = exc
    raise failure


def _print(value):
    print(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), flush=True)


def _write_result(directory, result, package=None):
    """Write one run's artifacts through the shared trusted writer.

    The same function the execution runner uses, so a CLI run and a browser run
    produce the same files under the same rules.
    """
    from .artifacts import artifact_records, write_artifacts

    return write_artifacts(directory, artifact_records(result, package))


def parser():
    root = argparse.ArgumentParser(
        prog="agentpkg",
        description="Agent Package v0: inspectable declarations, host-controlled authority",
    )
    root.add_argument(
        "--version",
        action="version",
        version=f"agentpkg {__version__} (agent.pkg 0.1, workflow.v0)",
    )
    commands = root.add_subparsers(dest="command", required=True)
    for name, help_text in [
        ("validate", "Validate source or artifact structure, schemas, references, and hashes"),
        ("inspect", "Inspect metadata without asserting publisher trust"),
        ("permissions", "Render requested permissions and execution limits"),
    ]:
        command = commands.add_parser(name, help=help_text)
        command.add_argument("package")
        if name == "inspect":
            command.add_argument(
                "--link",
                action="append",
                default=[],
                metavar="ID=ARCHIVE",
                help=(
                    "A linked package's archive for one declared dependency, repeatable; with "
                    "every dependency supplied, inspect states the composed worst case"
                ),
            )
    build = commands.add_parser(
        "build", help="Validate and reproducibly build a ZIP_STORED artifact"
    )
    build.add_argument("source")
    build.add_argument("-o", "--output", required=True)
    keys = commands.add_parser("keygen", help="Generate an Ed25519 key pair; never overwrite a key")
    keys.add_argument("--private-key", required=True)
    keys.add_argument("--public-key", required=True)
    sign = commands.add_parser(
        "sign", help="Sign a built artifact with an owner-only Ed25519 private key"
    )
    sign.add_argument("package")
    sign.add_argument("--private-key", required=True)
    sign.add_argument("-o", "--output")
    verify = commands.add_parser(
        "verify", help="Verify hashes and publisher signature against an external pinned key"
    )
    verify.add_argument("package")
    verify.add_argument("--trust-key", required=True)
    unpack = commands.add_parser(
        "unpack", help="Extract validated payload as a source tree in a new directory"
    )
    unpack.add_argument("package")
    unpack.add_argument("-o", "--output", required=True)
    install = commands.add_parser(
        "install-openclaw", help="Verify and stage package in a NEW OpenClaw-compatible workspace"
    )
    install.add_argument("package")
    install.add_argument("--workspace", required=True)
    install.add_argument("--trust-key", required=True)
    serve = commands.add_parser(
        "browser-serve",
        help="Run the loopback agent browser control plane (open/inspect/authorize only)",
    )
    serve.add_argument("--host", default="127.0.0.1", help="Loopback address only")
    serve.add_argument("--port", type=int, default=8765, help="0 selects a free port")
    serve.add_argument("--token", help="Bearer token; a random one is generated by default")
    serve.add_argument("--token-file", help="Also write the bearer token to this new 0600 file")
    serve.add_argument("--trust-store", help="Publisher trust store JSON path")
    serve.add_argument("--cache-dir", help="Private snapshot cache directory owned by the service")
    serve.add_argument(
        "--quiet",
        action="store_true",
        help="Omit the bearer token and per-request logs from stdout; requires --token-file",
    )
    serve.add_argument("--session-ttl", type=int, default=900, help="Package session lifetime")
    serve.add_argument("--max-sessions", type=int, default=8)
    serve.add_argument(
        "--allow-untrusted-publisher",
        action="store_true",
        help="Browser policy: issue runnable receipts for unpinned publishers (research use)",
    )
    serve.add_argument(
        "--allow-unsigned",
        action="store_true",
        help="Browser policy: issue runnable receipts without a valid signature (research use)",
    )
    serve.add_argument(
        "--allow-unverified-model",
        action="store_true",
        help=(
            "Browser policy: treat a model whose required capabilities the host cannot confirm "
            "as ready instead of unverified (research use; the real status is still recorded)"
        ),
    )
    commands.add_parser(
        "host-bridge",
        help=(
            "Run one trusted host model-router bridge session on stdio "
            "(private JSONL protocol; stdout carries frames only)"
        ),
    )
    runner = commands.add_parser(
        "execution-run",
        help=(
            "Run one workflow.v0 package execution session on stdio. Spawned by a trusted "
            "host with the immutable package archive on fd 3 and the run's artifact "
            "directory on fd 4; stdout carries protocol frames only"
        ),
    )
    runner.add_argument(
        "--link-fd",
        action="append",
        default=[],
        metavar="ID=FD",
        help=(
            "The inherited descriptor of one accepted linked package's archive, by "
            "dependency id (link.v0), repeatable"
        ),
    )
    commands.add_parser(
        "host-pdf-read",
        help=(
            "Extract bounded page text from PDF bytes on stdin and write one JSON document to "
            "stdout. Spawned by a trusted host tool broker per call; it opens no file"
        ),
    )
    trust = commands.add_parser(
        "trust", help="Manage the operator-controlled publisher trust store"
    )
    trust.add_argument("action", choices=["list", "add", "remove"])
    trust.add_argument("--trust-store", help="Publisher trust store JSON path")
    trust.add_argument("--public-key", help="Ed25519 SubjectPublicKeyInfo PEM file to pin")
    trust.add_argument("--display-name", help="Operator label for this publisher key")
    trust.add_argument("--publisher-id", help="Optional claimed publisher ID this key may sign")
    trust.add_argument("--package-id-prefix", help="Optional package ID prefix this key may sign")
    trust.add_argument("--note", help="Optional operator note")
    trust.add_argument("--fingerprint", help="sha256:<hex> entry to remove")
    trust.add_argument("--replace", action="store_true", help="Replace an existing pin")
    run = commands.add_parser("run", help="Execute any workflow.v0 package")
    run.add_argument("package")
    run.add_argument("--input", help="JSON input matching the package workflow input schema")
    run.add_argument("--mode", choices=["fixture", "live"], default="fixture")
    run.add_argument(
        "--grants",
        required=True,
        help="Host JSON map of permission IDs to once/session/always/deny",
    )
    run.add_argument(
        "--router-config",
        help="Host vendor-neutral router configuration; secrets remain in environment",
    )
    run.add_argument(
        "--trust-key",
        action="append",
        default=[],
        help=(
            "Required for live mode; validates the archive publisher before dispatch. "
            "Repeatable: a linked package's publisher is trusted when its key is one of these"
        ),
    )
    run.add_argument(
        "--link",
        action="append",
        default=[],
        metavar="ID=ARCHIVE",
        help=(
            "The archive of one declared dependency, repeatable; accepted only when its "
            "package digest is the pinned one. A dependency without one is fetched from its "
            "locator under the package-URL policy"
        ),
    )
    run.add_argument(
        "--link-grants",
        action="append",
        default=[],
        metavar="ID=GRANTS_JSON",
        help=(
            "Accept one linked publisher: the JSON map of that package's own permission IDs "
            "to once/session/always/deny. A caller's grants never reach a linked package"
        ),
    )
    run.add_argument(
        "--deny-link",
        action="append",
        default=[],
        metavar="ID",
        help="Deny one linked publisher: no inner run of its package starts",
    )
    run.add_argument(
        "--approve-tool",
        action="append",
        default=[],
        metavar="TOOL_ID",
        help=(
            "Approve one declared tool, repeatable. A granted permission is not an approval: "
            "the runtime refuses to dispatch any declared tool without one. A linked package's "
            "tool is named ID:TOOL_ID"
        ),
    )
    run.add_argument(
        "--selected-files", help="Host JSON map of selected file IDs to local PDF paths"
    )
    run.add_argument(
        "--resolver-base-url", help="Host HTTPS resolver override; cannot extend declared domains"
    )
    run.add_argument(
        "--limits", help="Optional host JSON limits, which can only lower package budgets"
    )
    run.add_argument(
        "--memory-dir",
        help=(
            "A memory.v0 folder (an export folder with sealed values in clear and its memory.key, "
            "generated when absent): the store the run's memory tools read and the egress scans "
            "check; live runs commit the package's agent document into it on completion"
        ),
    )
    run.add_argument(
        "--memory-grant",
        action="append",
        default=[],
        metavar="PERMISSION=RECORD",
        help="Grant one record of --memory-dir to a memory.read (or personal.read) permission",
    )
    run.add_argument("--out", required=True, help="New private output directory")
    converse = commands.add_parser(
        "converse",
        help=(
            "Run a conversation.v0 package turn by turn: a transcript of messages and consent "
            "decisions in, a transcript, the persisted state and one audit chain out"
        ),
    )
    converse.add_argument("package")
    converse.add_argument(
        "--transcript",
        help=(
            "The input transcript (conversation.transcript.v0: messages in order, per turn the "
            "decisions of the consent steps it may reach); in fixture mode the package's own "
            "conversation fixture is replayed when this is absent"
        ),
    )
    converse.add_argument("--mode", choices=["fixture", "live"], default="fixture")
    converse.add_argument(
        "--grants",
        required=True,
        help=(
            "Host JSON map of permission IDs to once/session/always/deny; a `once` grant is "
            "spent by its first use in the conversation"
        ),
    )
    converse.add_argument("--router-config", help="Host router configuration (live mode)")
    converse.add_argument("--trust-key", help="Required for live mode; verifies the publisher")
    converse.add_argument(
        "--approve-tool", action="append", default=[], metavar="TOOL_ID", help="As for run"
    )
    converse.add_argument("--selected-files", help="As for run")
    converse.add_argument("--resolver-base-url", help="As for run")
    converse.add_argument(
        "--limits",
        help=(
            "Optional host JSON limits: the turn's (as for run) and the conversation's "
            "conversation_max_turns, conversation_total_tokens, conversation_max_remote_calls; "
            "each can only lower the package's"
        ),
    )
    converse.add_argument("--memory-dir", help="As for run; the same folder serves every turn")
    converse.add_argument(
        "--memory-grant",
        action="append",
        default=[],
        metavar="PERMISSION=RECORD",
        help="As for run",
    )
    converse.add_argument("--out", required=True, help="New private output directory")
    evaluate = commands.add_parser(
        "eval", help="Run the supported host evaluation harness with explicit synthetic fixtures"
    )
    evaluate.add_argument("package")
    evaluate.add_argument("--out", help="Optional new directory for the evaluation report")
    return root


def _browser(args):
    """Control-plane commands. No package is executed by any of them."""
    from .browser import (
        BrowserPolicy,
        BrowserService,
        ControlPlane,
        ControlPlaneConfig,
        TrustStore,
        default_cache_dir,
        default_trust_store,
    )
    from .browser.trust import read_public_key_file

    store_path = Path(args.trust_store) if args.trust_store else default_trust_store()
    if args.command == "trust":
        store = TrustStore(store_path)
        if args.action == "list":
            return {
                "trust_store": store.state(),
                "publishers": [entry.as_json() for entry in store.entries()],
            }
        if args.action == "add":
            if not args.public_key or not args.display_name:
                raise AgentPkgError("trust add requires --public-key and --display-name")
            entry = store.add(
                read_public_key_file(args.public_key),
                display_name=args.display_name,
                publisher_id=args.publisher_id,
                package_id_prefix=args.package_id_prefix,
                notes=args.note,
                replace=args.replace,
            )
            return {"added": entry.as_json(), "trust_store": store.state()}
        if not args.fingerprint:
            raise AgentPkgError("trust remove requires --fingerprint sha256:<hex>")
        entry = store.remove(args.fingerprint)
        return {"removed": entry.as_json(), "trust_store": store.state()}

    config = ControlPlaneConfig(
        cache_dir=Path(args.cache_dir) if args.cache_dir else default_cache_dir(),
        trust_store_path=store_path,
        session_ttl_seconds=args.session_ttl,
        max_sessions=args.max_sessions,
        policy=BrowserPolicy(
            require_valid_signature=not args.allow_unsigned,
            require_trusted_publisher=not args.allow_untrusted_publisher,
            require_confirmed_model_compatibility=not args.allow_unverified_model,
        ),
    )
    if args.quiet and not (args.token_file or args.token):
        # A supervising host must still be able to obtain the token out of band.
        raise AgentPkgError("--quiet requires --token-file (or an explicit --token)")
    service = BrowserService(
        ControlPlane(config), host=args.host, port=args.port, token=args.token, quiet=args.quiet
    )
    if args.token_file:
        write_new(args.token_file, (service.token + "\n").encode(), mode=0o600)
    startup = {
        "service": "agentpkg-browser-control-plane",
        "status": "listening",
        "url": service.url,
        "api_version": "v0",
        **({} if args.quiet else {"token": service.token}),
        "token_file": args.token_file,
        "cache_dir": str(service.control.cache_dir),
        "trust_store": str(store_path),
        "execution": "disabled",
        "hint": f"curl -sS {service.url}/v0/health",
    }
    if args.quiet:
        # One compact line, so a supervising host can parse readiness without
        # buffering an indented document.
        print(json.dumps(startup, ensure_ascii=False, allow_nan=False), flush=True)
    else:
        _print(startup)

    def stop(*_):
        raise KeyboardInterrupt

    try:
        # A terminated service should still purge its snapshots; a hard kill is
        # covered by the next start's stale-snapshot sweep.
        signal.signal(signal.SIGTERM, stop)
    except ValueError:
        pass
    try:
        service.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        service.shutdown()
        service.server_close()
    return {"service": "agentpkg-browser-control-plane", "status": "stopped"}


def _dispatch(args):
    command = args.command
    if command == "build":
        path = build_package(args.source, args.output)
        return {"artifact": str(path), "digest": load_package(path).digest}
    if command == "keygen":
        return keygen(args.private_key, args.public_key)
    if command == "sign":
        path = sign_package(args.package, args.private_key, args.output)
        return {
            "artifact": str(path),
            "signed": True,
            "digest": load_package(path).digest,
            "trust": "Verify using a separately pinned publisher public key",
        }
    if command == "verify":
        return verify_package(args.package, trusted_key=args.trust_key)
    if command == "unpack":
        return {
            "source": str(unpack_package(args.package, args.output)),
            "signature_preserved": False,
        }
    if command in ("browser-serve", "trust"):
        return _browser(args)
    if command == "host-bridge":
        # stdout belongs to the protocol from here on: this returns the process
        # exit status directly and prints nothing.
        from .hostbridge import serve

        return _Exit(asyncio.run(serve()))
    if command == "execution-run":
        # The runner. stdout is the protocol; the package and the artifact
        # directory arrive as inherited descriptors, so no path is named here.
        from .execution import serve as serve_execution

        link_fds = {name: int(value) for name, value in _pairs(args.link_fd, "--link-fd").items()}
        return _Exit(asyncio.run(serve_execution(link_fds=link_fds)))
    if command == "host-pdf-read":
        # A trusted host capability, not a package operation: bytes arrive on
        # stdin from the broker that holds the person's selection, and the
        # answer is the only thing written to stdout.
        from .hostfiles import serve_stdin

        return _Exit(serve_stdin())
    if command == "install-openclaw":
        from .openclaw import stage_openclaw

        return stage_openclaw(args.package, args.workspace, trusted_key_path=args.trust_key)
    package = load_package(args.package)
    if command == "validate":
        return {
            "valid": True,
            "package_id": package.manifest["package_id"],
            "version": package.manifest["version"],
            "digest": package.digest,
            "signature_present": package.signature is not None,
            "publisher_trust": "not checked; use verify --trust-key",
        }
    if command == "inspect":
        listing = inspect_package(package)
        supplied = _pairs(args.link, "--link")
        declared = [r.get("id") for r in package.manifest["dependencies"]]
        if supplied and set(supplied) == set(declared):
            # link.v0 L-22: with every dependency supplied, the composed envelope.
            from .delegation.declarations import network_records
            from .links.records import link_records
            from .links.resolve import resolve_links

            resolved = resolve_links(
                package,
                {name: Path(path).read_bytes() for name, path in supplied.items()},
                trust=lambda signer, linked: "not evaluated by inspect",
            )
            listing["links"] = link_records(package, resolved)
            if "network" in listing:
                listing["network"] = network_records(
                    package, {name: link.worst_case for name, link in resolved.items()}
                )
        return listing
    if command == "permissions":
        return permissions_summary(package)
    if command == "converse":
        return _converse(args, package)
    if command in ("run", "eval"):
        from .fixtures import fixture_adapters
        from .workflow import run_workflow

        if package.manifest["entrypoint"] != "workflow.v0":
            raise AgentPkgError(
                "Generic execution requires workflow.v0; use agentpkg-legacy "
                "for the archived development profile"
            )
        if package.graph.get("conversation") is not None:
            # conversation.v0: a turn starts from a persisted state a single run does not have.
            raise AgentPkgError(
                "conversation_profile: this package declares a conversation and runs turn by "
                "turn; use agentpkg converse"
            )
        mode = args.mode if command == "run" else "fixture"
        trust_keys = list(getattr(args, "trust_key", None) or [])
        if mode == "live" and not trust_keys:
            raise AgentPkgError("Live run requires a signed artifact and --trust-key PUBLIC_KEY")
        if command == "run" and trust_keys:
            verified = _verify_under(args.package, trust_keys)
            if verified["digest"] != package.digest:
                raise AgentPkgError("Package changed between loading and signature verification")
        if mode == "fixture":
            router, handlers, input_value = fixture_adapters(package)
        else:
            from .models import HTTPRouter
            from .tools import create_handlers

            if not args.router_config or not args.input:
                raise AgentPkgError("Live workflow execution requires --router-config and --input")
            router = HTTPRouter.from_config(args.router_config)
            handlers = create_handlers(
                package,
                selected_files=(_json_file(args.selected_files) if args.selected_files else None),
                resolver_base_url=args.resolver_base_url,
            )
            input_value = _json_file(args.input, None)
        grants = (
            _json_file(args.grants)
            if command == "run"
            else {p["id"]: "session" for p in package.policy["permissions"]}
        )
        if command == "run" and args.input:
            input_value = _json_file(args.input, None)
        # The operator is the host here. `run` requires each tool to be named,
        # because approving a tool is a separate decision from granting the
        # permission it travels under. `eval` runs the package's own declared
        # fixtures under blanket consent, which is already what its grants say.
        from .links.operator import operator_links, split_tool_approvals

        approved, linked_approvals = (
            split_tool_approvals(package, args.approve_tool or ())
            if command == "run"
            else (sorted(package.tools), {})
        )
        unknown = sorted(set(approved) - set(package.tools))
        if unknown:
            raise AgentPkgError(
                f"--approve-tool names tools this package does not declare: {unknown}"
            )
        # memory.v0 (agentpkg 0.4.0): the run's memory from --memory-dir, or in fixture mode from
        # the package's own replayed answers (M-62, M-63, D-230).
        from .memory.host import cli_memory

        memory_run, _folder, memory_handlers = cli_memory(
            package,
            mode=mode,
            decisions=grants,
            memory_dir=getattr(args, "memory_dir", None),
            memory_grants=getattr(args, "memory_grant", None) or (),
        )
        if mode == "live":
            handlers = {**handlers, **memory_handlers}
        options = dict(
            grants=grants,
            handlers=handlers,
            router=router,
            approved_tools=approved,
            memory=memory_run,
        )
        if command == "run":
            # link.v0 §3 with the operator as the person: every dependency resolved (a supplied
            # archive by its digest, else its locator) and decided, before anything runs.
            from .signing import _read_key, fingerprint

            decisions = {
                name: {
                    "decision": "accepted",
                    "grants": _json_file(path),
                    "approved_tools": linked_approvals.get(name, []),
                }
                for name, path in _pairs(args.link_grants, "--link-grants").items()
            }
            for name in args.deny_link:
                if name in decisions:
                    raise AgentPkgError(f"--deny-link and --link-grants both name {name!r}")
                decisions[name] = {"decision": "denied"}

            def adapters(linked):
                if mode == "fixture":
                    return fixture_adapters(linked)[:2]
                from .tools import create_handlers

                return None, create_handlers(linked)

            links = operator_links(
                package,
                archives=_pairs(args.link, "--link"),
                decisions=decisions,
                trusted={fingerprint(_read_key(path)) for path in trust_keys},
                require_trusted=mode == "live",
                router=router,
                adapters=adapters,
            )
            if links is not None:
                options["links"] = links
        if command == "run" and args.limits:
            options["limits"] = _json_file(args.limits)
        if args.out:
            if (
                Path(args.out).exists()
                or Path(args.out).is_symlink()
                or not Path(args.out).parent.is_dir()
            ):
                raise ValidationError("--out must name a new directory under an existing parent")
            import os

            parent_fd, _ = _open_parent(args.out)
            os.close(parent_fd)
        try:
            result = asyncio.run(run_workflow(package, input_value, **options))
        except Exception as exc:
            report = getattr(exc, "execution_report", None)
            if report is not None and args.out:
                _write_result(args.out, report)
            raise
        if args.out:
            _write_result(args.out, result, package)
        if memory_run.commit_error:
            # M-50: the folder refused the agent document; the Run Record says `store_failed`.
            print(
                f"agentpkg: the agent document was not committed: {memory_run.commit_error}",
                file=sys.stderr,
            )
        return {
            "status": result["status"],
            "profile": "workflow.v0",
            "output_directory": args.out,
            "usage": result["usage"],
            "approved_tools": approved,
            "fixture_replay": mode == "fixture",
            "passed": result["status"] == "completed",
        }
    raise AgentPkgError(f"Unsupported command: {command}")


def _converse(args, package):
    """`agentpkg converse`: one conversation of a conversation.v0 package from a transcript.

    The host here is the operator: the grants are the plan's decisions for the whole conversation,
    the transcript's consent decisions stand for the person's, and each turn's adapters are the
    ones `run` would build (fixture replay, or the live router and handlers over the same memory
    folder). Every turn's artifacts go to `turn-NNN/` under `--out` as the turn ends; the
    conversation's transcript, state, one audit chain, usage and provenance are written last.
    """
    from .artifacts import artifact_records, write_artifacts
    from .conversation import Conversation
    from .conversation.transcript import check_transcript, read_input_transcript
    from .fixtures import fixture_adapters
    from .memory.host import cli_memory
    from .package import create_directory

    if package.graph.get("conversation") is None:
        raise AgentPkgError(
            "conversation_profile_required: this package declares no conversation; use agentpkg run"
        )
    mode = args.mode
    if mode == "live" and not args.trust_key:
        raise AgentPkgError("Live run requires a signed artifact and --trust-key PUBLIC_KEY")
    if args.trust_key:
        verified = verify_package(args.package, trusted_key=args.trust_key)
        if verified["digest"] != package.digest:
            raise AgentPkgError("Package changed between loading and signature verification")
    if args.transcript:
        transcript = read_input_transcript(args.transcript)
    elif mode == "fixture" and package.graph["conversation"].get("fixture"):
        transcript = package.json(package.graph["conversation"]["fixture"])
    else:
        raise AgentPkgError(
            "A conversation needs --transcript (in fixture mode the package's conversation "
            "fixture serves when it declares one)"
        )
    grants = _json_file(args.grants)
    # An approval of an undeclared tool is refused by the conversation's own check (T23 review 2).
    approved = sorted(set(args.approve_tool or ()))
    check_transcript(transcript, package, grants)
    if mode == "fixture":
        router, handlers, _ = fixture_adapters(package)
    else:
        from .models import HTTPRouter
        from .tools import create_handlers

        if not args.router_config:
            raise AgentPkgError("Live conversation requires --router-config")
        router = HTTPRouter.from_config(args.router_config)
        handlers = create_handlers(
            package,
            selected_files=(_json_file(args.selected_files) if args.selected_files else None),
            resolver_base_url=args.resolver_base_url,
        )

    memory_runs = {}

    def memory_for_turn():
        # A fresh memory run per turn over the same folder (M-50 per turn, V-26).
        return cli_memory(
            package,
            mode=mode,
            decisions=grants,
            memory_dir=args.memory_dir,
            memory_grants=args.memory_grant or (),
        )

    # The memory inputs (the folder, `--memory-grant`) are resolved for the first turn before
    # `--out` exists, so a refused folder or grant leaves no half-made directory behind (T23
    # review 2, nit 1); later turns resolve their own run over the same folder.
    first_memory = memory_for_turn()

    def adapters(turn):
        memory_run, _folder, memory_handlers = first_memory if turn == 1 else memory_for_turn()
        memory_runs[turn] = memory_run
        return {
            "router": router,
            "handlers": {**handlers, **memory_handlers} if mode == "live" else handlers,
            "memory": memory_run,
        }

    out = Path(args.out)
    if out.exists() or out.is_symlink() or not out.parent.is_dir():
        raise ValidationError("--out must name a new directory under an existing parent")

    def on_turn(index, report, status):
        records = artifact_records(report, package if status == "completed" else None)
        write_artifacts(out / f"turn-{index:03d}", records)
        memory_run = memory_runs.pop(index, None)
        if memory_run is not None and memory_run.commit_error:
            # M-50 per turn: the folder refused the agent document; the turn's Run Record says
            # `store_failed`, as `run` reports it for a run.
            print(
                f"agentpkg: turn {index}: the agent document was not committed: "
                f"{memory_run.commit_error}",
                file=sys.stderr,
            )

    # The conversation checks the grants, the approvals and the limits before anything is
    # written, so a refused host input leaves no half-made --out behind.
    conversation = Conversation(
        package,
        grants=grants,
        approved_tools=approved,
        adapters=adapters,
        limits=_json_file(args.limits) if args.limits else None,
        on_turn=on_turn,
    )
    create_directory(out)
    result = asyncio.run(conversation.run(transcript))
    for name, value in (
        ("transcript.json", result["transcript"]),
        ("state.json", result["state"]),
        ("audit.json", result["audit"]),
        ("usage.json", result["usage"]),
        ("provenance.json", result["provenance"]),
    ):
        data = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()
        write_new(out / name, data, mode=0o600)
    return {
        "status": result["status"],
        "profile": "conversation.v0",
        "conversation_id": result["provenance"]["conversation_id"],
        "output_directory": args.out,
        "turns": [
            {"turn": t["turn"], "status": t["status"]} for t in result["transcript"]["turns"]
        ],
        "ended": result["ended"],
        "usage": {
            key: result["usage"][key] for key in ("turns", "tokens", "remote_calls", "tool_calls")
        },
        "approved_tools": approved,
        "fixture_replay": mode == "fixture",
        "passed": result["status"] == "completed",
    }


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        result = _dispatch(args)
        if isinstance(result, _Exit):
            return int(result)
        _print(result)
        if args.command in ("eval", "converse") and result.get("passed") is False:
            return 1
        return 0
    except (AgentPkgError, OSError, ValueError) as exc:
        print(f"agentpkg: {exc}", file=sys.stderr)
        return 2
